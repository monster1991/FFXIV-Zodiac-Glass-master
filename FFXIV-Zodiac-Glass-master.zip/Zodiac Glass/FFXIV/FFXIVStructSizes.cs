﻿namespace ZodiacGlass.FFXIV
{
    internal static class FFXIVStructSizes
    {
        internal const int Weapon = 64;
        internal const int Item = 64;
        internal const int ItemSet = 834;  // 8 + 13 * 64
    }
}
