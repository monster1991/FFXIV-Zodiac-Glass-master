﻿namespace ZodiacGlass.FFXIV
{
    enum FFXIVScreenMode
    {
        Unknwon = -1,
        Window = 0,
        FullScreen = 1,
        FramelessWindow = 2
    }
}
