﻿namespace ZodiacGlass
{
    internal static class AssemblyProperties
    {
        internal const string Version = "1.4.1603.20001"; // X.X.Year_Year_Month_Mont.Day_Day_BuildOfDayBuildOfDayBuildOfDay
        internal const string Name = "Zodiac Glass";
        internal const string Copyright = "© 2016 Martin Kuschnik";
    }
}
