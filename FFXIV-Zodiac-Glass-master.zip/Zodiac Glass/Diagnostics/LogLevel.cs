﻿namespace ZodiacGlass.Diagnostics
{
    enum LogLevel
    {
        Trace,
        Info,
        Error
    }
}
