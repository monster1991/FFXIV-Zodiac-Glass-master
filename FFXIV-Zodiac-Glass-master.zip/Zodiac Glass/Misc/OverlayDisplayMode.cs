﻿namespace ZodiacGlass
{
    public enum OverlayDisplayMode
    {
        Normal,
        Percentage
    }
}
